Clazz.declarePackage ("JSV.api");
Clazz.declareInterface (JSV.api, "JSVAppletInterface");
